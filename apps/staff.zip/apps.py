from django.apps import AppConfig

class StaffConfig(AppConfig):
    name = "apps.staff"
    label = "staff"
    verbose_name = "Staff"
