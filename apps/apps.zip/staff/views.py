from django.shortcuts import get_object_or_404
from django.utils.dateparse import parse_datetime
from django.http import StreamingHttpResponse, HttpResponse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views import View

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.parsers import MultiPartParser, FormParser

import io
import csv
import json

from .models import Staff
from apps.catalog.models import MenuItem
from .auth import StaffJWTAuthentication, issue_access_token, set_auth_cookie, clear_auth_cookie
from .permissions import IsOwnerOrManager
from .serializers import (
    StaffLoginSerializer,
    CouponSerializer, MembershipSerializer,
    StaffMeSerializer,
    StaffOrderDetailSerializer,
    InventoryItemUpdateSerializer,
    InventoryItemPartialUpdateSerializer,
)
from apps.promotion.models import Coupon, Membership
from apps.orders.models import Order
from .eventbus import iter_order_notifications

# ---------- Auth ----------
class StaffLoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        ser = StaffLoginSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        username = (ser.validated_data["username"] or "").strip()
        password = ser.validated_data["password"]

        staff = Staff.objects.filter(username__iexact=username).first()
        if not staff or not staff.check_password(password):
            return Response({"detail": "아이디 또는 비밀번호가 올바르지 않습니다."},
                            status=status.HTTP_400_BAD_REQUEST)

        token = issue_access_token(staff)
        resp = Response({"status": True, "staff_id": staff.pk})
        set_auth_cookie(resp, token)
        return resp

class StaffLogoutView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        resp = Response({"status": True})
        clear_auth_cookie(resp)
        return resp

class StaffMeView(APIView):
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(StaffMeSerializer(request.user).data)

# ---------- Coupons ----------
class CouponsView(APIView):
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        qs = Coupon.objects.all().order_by("-valid_from", "code")
        return Response(CouponSerializer(qs, many=True).data)

    def post(self, request):
        if not IsOwnerOrManager().has_permission(request, self):
            return Response({"detail": "권한이 없습니다."}, status=status.HTTP_403_FORBIDDEN)
        ser = CouponSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        obj = ser.save()
        return Response(CouponSerializer(obj).data, status=status.HTTP_201_CREATED)

class CouponDetailView(APIView):
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_object(self, code: str) -> Coupon:
        return get_object_or_404(Coupon, code=code.upper())

    def get(self, request, code: str):
        return Response(CouponSerializer(self.get_object(code)).data)

    def patch(self, request, code: str):
        if not IsOwnerOrManager().has_permission(request, self):
            return Response({"detail": "권한이 없습니다."}, status=status.HTTP_403_FORBIDDEN)
        obj = self.get_object(code)
        ser = CouponSerializer(instance=obj, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        return Response(CouponSerializer(obj).data)

    def delete(self, request, code: str):
        if not IsOwnerOrManager().has_permission(request, self):
            return Response({"detail": "권한이 없습니다."}, status=status.HTTP_403_FORBIDDEN)
        obj = self.get_object(code)
        if hasattr(obj, "active"):
            obj.active = False
            obj.save(update_fields=["active"])
            return Response(status=status.HTTP_204_NO_CONTENT)
        obj.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# ---------- Memberships ----------
class MembershipsView(APIView):
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        qs = Membership.objects.all().order_by("customer_id")
        return Response(MembershipSerializer(qs, many=True).data)

    def post(self, request):
        if not IsOwnerOrManager().has_permission(request, self):
            return Response({"detail": "권한이 없습니다."}, status=status.HTTP_403_FORBIDDEN)
        ser = MembershipSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        if Membership.objects.filter(customer=ser.validated_data["customer"]).exists():
            return Response({"detail": "이미 해당 고객의 멤버십이 존재합니다."}, status=status.HTTP_400_BAD_REQUEST)
        obj = ser.save()
        return Response(MembershipSerializer(obj).data, status=status.HTTP_201_CREATED)

class MembershipDetailView(APIView):
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_object(self, customer_id: int) -> Membership:
        return get_object_or_404(Membership, customer_id=customer_id)

    def get(self, request, customer_id: int):
        obj = self.get_object(customer_id)
        return Response(MembershipSerializer(obj).data)

    def patch(self, request, customer_id: int):
        if not IsOwnerOrManager().has_permission(request, self):
            return Response({"detail": "권한이 없습니다."}, status=status.HTTP_403_FORBIDDEN)
        obj = self.get_object(customer_id)
        ser = MembershipSerializer(instance=obj, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        if "customer" in ser.validated_data and ser.validated_data["customer"].pk != obj.customer_id:
            return Response({"detail": "customer는 변경할 수 없습니다."}, status=status.HTTP_400_BAD_REQUEST)
        ser.save()
        return Response(MembershipSerializer(obj).data)

    def delete(self, request, customer_id: int):
        if not IsOwnerOrManager().has_permission(request, self):
            return Response({"detail": "권한이 없습니다."}, status=status.HTTP_403_FORBIDDEN)
        obj = self.get_object(customer_id)
        if hasattr(obj, "active"):
            obj.active = False
            obj.save(update_fields=["active"])
            return Response(status=status.HTTP_204_NO_CONTENT)
        obj.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# ---------- Orders: 단건 상세 ----------
class StaffOrderDetailView(APIView):
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request, order_id: int):
        order = (
            Order.objects
            .select_related("customer")
            .prefetch_related(
                "dinners__items__item",
                "dinners__items__options",
                "dinners__options",
                "coupon_redemptions__coupon",
            )
            .get(pk=order_id)
        )
        return Response(StaffOrderDetailSerializer(order).data, status=status.HTTP_200_OK)

# ---------- SSE (Orders) ----------
def _sse_headers(resp: StreamingHttpResponse) -> StreamingHttpResponse:
    resp["Content-Type"] = "text/event-stream; charset=utf-8"
    resp["Cache-Control"] = "no-cache, no-transform"
    return resp

@method_decorator(csrf_exempt, name="dispatch")
class OrdersSSEView(View):
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def dispatch(self, request, *args, **kwargs):
        # 수동 인증(StreamingHttpResponse + DRF 혼용 시)
        authed = False
        for cls in self.authentication_classes:
            inst = cls()
            res = inst.authenticate(request)
            if res:
                request.user, request.auth = res
                authed = True
                break
        if not authed:
            return HttpResponse("Unauthorized", status=401)
        for perm in self.permission_classes:
            if not perm().has_permission(request, self):
                return HttpResponse("Forbidden", status=403)
        return super().dispatch(request, *args, **kwargs)

    def _bootstrap(self, request):
        status_param = (request.GET.get("status") or "").strip()
        since_param = (request.GET.get("since") or "").strip()
        limit = int(request.GET.get("limit") or 20)
        limit = max(1, min(limit, 100))

        qs = Order.objects.all().order_by("-ordered_at")
        if status_param:
            statuses = [s.strip() for s in status_param.split(",") if s.strip()]
            qs = qs.filter(status__in=statuses)
        if since_param:
            dt = parse_datetime(since_param)
            if dt:
                qs = qs.filter(ordered_at__gte=dt)

        out = []
        for o in qs[:limit]:
            out.append({
                "id": o.id,
                "status": o.status,
                "ordered_at": o.ordered_at.isoformat(),
                "customer_id": o.customer_id,
                "order_source": o.order_source,
                "subtotal_cents": o.subtotal_cents,
                "total_cents": o.total_cents,
                "receiver_name": o.receiver_name,
                "place_label": o.place_label,
            })
        return out

    def get(self, request):
        def stream():
            yield "event: bootstrap\n"
            yield "data: " + json.dumps(self._bootstrap(request), ensure_ascii=False) + "\n\n"
            for msg in iter_order_notifications():
                name = msg.get("event", "message")
                yield f"event: {name}\n"
                yield "data: " + json.dumps(msg, ensure_ascii=False) + "\n\n"
        return _sse_headers(StreamingHttpResponse(stream()))

# ---------- Inventory (사람 주도) ----------
class InventoryItemsView(APIView):
    """
    GET  /api/staff/inventory/items      : 목록/검색
    POST /api/staff/inventory/items      : 일괄 수정 (qty/ delta / active / reason)
    자동 토글/방송 없음 — 사람 판단 우선
    """
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        qs = MenuItem.objects.all().select_related("category")
        q = (request.query_params.get("q") or "").strip()
        if q:
            qs = qs.filter(name__icontains=q) | qs.filter(code__icontains=q)
        active_param = request.query_params.get("active")
        if active_param is not None:
            val = str(active_param).lower() in ("1","true","t","yes","y")
            qs = qs.filter(active=val)
        qs = qs.order_by("category__rank", "name")
        out = []
        for it in qs[:500]:
            attrs = dict(getattr(it, "attrs", {}) or {})
            qty = int(attrs.get("stock_qty") or 0)
            out.append({
                "code": it.code,
                "name": it.name,
                "active": it.active,
                "qty": qty,
                "category": getattr(getattr(it, "category", None), "name", None),
                "soldout_reason": attrs.get("soldout_reason"),
                "price_cents": getattr(it, "base_price_cents", None),
                "updated_at": getattr(it, "updated_at", None).isoformat() if getattr(it, "updated_at", None) else None,
            })
        return Response({"count": len(out), "items": out})

    def post(self, request):
        data = request.data or {}
        items = data.get("items")
        if not isinstance(items, list) or not items:
            return Response({"detail": "items 배열이 필요합니다."}, status=400)

        validated = []
        for idx, row in enumerate(items, start=1):
            s = InventoryItemUpdateSerializer(data=row)
            if not s.is_valid():
                return Response({"detail": f"items[{idx}] 유효하지 않습니다.", "errors": s.errors}, status=400)
            validated.append(s.validated_data)

        changed = []
        for row in validated:
            code = row["code"].strip()
            it = MenuItem.objects.filter(code=code).first()
            if not it:
                continue

            attrs = dict(getattr(it, "attrs", {}) or {})
            qty = int(attrs.get("stock_qty") or 0)

            if "qty" in row and row.get("qty") is not None:
                qty = max(0, int(row["qty"]))
            if "delta" in row and row.get("delta") is not None:
                qty = max(0, qty + int(row["delta"]))

            attrs["stock_qty"] = int(qty)

            if "active" in row:
                it.active = bool(row["active"])

            reason = row.get("reason")
            if reason is not None:
                attrs["soldout_reason"] = reason if not it.active or qty == 0 else None

            it.attrs = attrs
            if hasattr(it, "updated_at"):
                it.save(update_fields=["active", "attrs", "updated_at"])
            else:
                it.save(update_fields=["active", "attrs"])
            changed.append({"code": it.code, "active": it.active, "qty": attrs["stock_qty"]})
        return Response({"updated": changed}, status=200)

class InventoryItemDetailView(APIView):
    """단건 재고 수정: PATCH /api/staff/inventory/items/{code}"""
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]

    def patch(self, request, code: str):
        it = get_object_or_404(MenuItem, code=code)
        s = InventoryItemPartialUpdateSerializer(data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        attrs = dict(getattr(it, "attrs", {}) or {})
        qty = int(attrs.get("stock_qty") or 0)

        if "qty" in data:
            qty = max(0, int(data["qty"]))
        if "delta" in data:
            qty = max(0, qty + int(data["delta"]))

        attrs["stock_qty"] = int(qty)

        if "active" in data:
            it.active = bool(data["active"])

        if "reason" in data:
            reason = data.get("reason")
            attrs["soldout_reason"] = reason if (reason is not None and (not it.active or qty == 0)) else attrs.get("soldout_reason")

        it.attrs = attrs
        if hasattr(it, "updated_at"):
            it.save(update_fields=["active", "attrs", "updated_at"])
        else:
            it.save(update_fields=["active", "attrs"])

        return Response({"code": it.code, "active": it.active, "qty": attrs["stock_qty"], "attrs": attrs})

class InventoryUploadView(APIView):
    """
    마감 후 재고조사 XLSX/CSV 업로드 → 수량 절대 반영
    필수 헤더: code|item_code, qty|quantity
    선택 헤더: active, reason
    """
    authentication_classes = [StaffJWTAuthentication]
    permission_classes = [IsAuthenticated]
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request):
        f = request.FILES.get("file")
        if not f:
            return Response({"detail": "file 필드에 XLSX/CSV 파일을 업로드하세요."}, status=400)

        filename = getattr(f, "name", "upload.bin").lower()
        rows, errors = [], []

        def norm(h): return str(h or "").strip().lower().replace(" ", "").replace("-", "").replace("_", "")

        def push_row(d, idx):
            code = (d.get("code") or d.get("item_code") or "").strip()
            qty = d.get("qty") if d.get("qty") is not None else d.get("quantity")
            reason = d.get("reason")
            active = d.get("active")
            if not code:
                errors.append({"row": idx, "detail": "code 비어있음"}); return
            if qty is None:
                errors.append({"row": idx, "detail": "qty/quantity 누락"}); return
            try:
                qty = max(0, int(qty))
            except Exception:
                errors.append({"row": idx, "detail": f"qty 정수 아님: {qty}"}); return
            rows.append({"code": code, "qty": qty, "reason": reason, "active": active})

        # 안전하진 않음
        if filename.endswith(".xlsx"):
            try:
                from openpyxl import load_workbook
            except Exception:
                return Response({"detail": "server error"}, status=500)
            wb = load_workbook(filename=io.BytesIO(f.read()), read_only=True, data_only=True)
            ws = wb.active
            headers = [norm(c.value) for c in next(ws.iter_rows(min_row=1, max_row=1))]
            idx_map = {h: i for i, h in enumerate(headers)}
            for r_idx, row in enumerate(ws.iter_rows(min_row=2), start=2):
                data = {}
                for key in ["code", "item_code", "qty", "quantity", "reason", "active"]:
                    pos = idx_map.get(norm(key))
                    if pos is not None and pos < len(row):
                        data[key] = row[pos].value
                push_row(data, r_idx)

        if errors:
            return Response({"updated": 0, "errors": errors}, status=400)

        updated = []
        for r in rows:
            it = MenuItem.objects.filter(code=r["code"]).first()
            if not it:
                errors.append({"code": r["code"], "detail": "해당 code의 MenuItem 없음"}); continue
            attrs = dict(getattr(it, "attrs", {}) or {})
            attrs["stock_qty"] = int(r["qty"])
            if r.get("reason") is not None:
                attrs["soldout_reason"] = r["reason"]
            if r.get("active") is not None:
                val = str(r["active"]).strip().lower()
                it.active = True if val in ("1", "true", "t", "yes", "y") else False
            it.attrs = attrs
            if hasattr(it, "updated_at"):
                it.save(update_fields=["attrs", "active", "updated_at"])
            else:
                it.save(update_fields=["attrs", "active"])
            updated.append({"code": it.code, "qty": attrs["stock_qty"], "active": it.active})

        status_code = 200 if not errors else 207
        return Response({"updated": updated, "errors": errors}, status=status_code)
